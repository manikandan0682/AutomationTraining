package main

import "multi/h1"
import "multi/h2"

func main() {
	h1.FuncA()
	h2.FuncB()
}
