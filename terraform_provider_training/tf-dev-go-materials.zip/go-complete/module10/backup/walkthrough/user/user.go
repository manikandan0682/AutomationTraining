package main

import (
	"github.com/donismarshall/lab/greeting"
)

func main() {
	greeting.Hello()
}
