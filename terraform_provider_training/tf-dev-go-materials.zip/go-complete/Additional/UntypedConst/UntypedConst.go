

package main

func main() {
	const a int = 5
	const b = 5  // untyped const

	var c float32 = a

	var d float32 = b
}
