package h1

import "fmt"

func FuncA() {
	fmt.Println("FuncA")
}
