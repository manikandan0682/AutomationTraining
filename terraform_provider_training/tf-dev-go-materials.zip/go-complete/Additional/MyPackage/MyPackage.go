package main

import (
	"mypackage/lib"
)

func main() {
	lib.FuncA()
}
