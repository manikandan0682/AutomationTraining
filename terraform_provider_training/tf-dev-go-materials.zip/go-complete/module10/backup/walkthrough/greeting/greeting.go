package greeting

import "fmt"

func Hello() {
	fmt.Println("Hello, world!")
}
