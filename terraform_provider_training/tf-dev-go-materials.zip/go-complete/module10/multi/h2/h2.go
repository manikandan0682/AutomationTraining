package h2

import "fmt"

func FuncB() {
	fmt.Println("FuncB")
}
