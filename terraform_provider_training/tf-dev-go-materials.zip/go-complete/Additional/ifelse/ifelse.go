package main

import "fmt"

func main() {

	if a := 5; a > 4 {
		fmt.Println(a)
	} else {
		fmt.Println("cool!")
	}
}
