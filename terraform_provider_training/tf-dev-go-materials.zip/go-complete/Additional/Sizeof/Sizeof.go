package main

import "fmt"

func main() {

	a := "Hello!"

	fmt.Println([]byte(a))
	fmt.Println([]rune(a))
}
